export function Divider() {
  const styles = {
    border: '1px solid rgba(0, 0, 0, 3)', 
    margin: '20px'
  };
   return (
     <div style={styles}></div>
   );
}
