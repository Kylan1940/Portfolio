import { siteConfig } from "../lib/data";

export function Footer() {
    const styles = {
        margin: '0 0 20px 0'
    }
    const year = new Date().getFullYear();
    return (
        <footer className="border-t border-neutral-200 mt-20 py-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <p className="font-mono text-xs text-neutral-400">{siteConfig.name}</p>
            <p className="font-mono text-xs text-neutral-300 margin" style={styles}>{year}</p>
        </div>
        </footer>
    );
}
