export function About() {
    return (
    <section id="about" className="min-h-screen w-full flex flex-col items-center justify-center px-6">
        <div className="mx-auto max-w-6xl text-center">
            <h1>Section 2</h1>
            <a
                href="#hero"
                onClick={(e) => {
                    e.preventDefault();
                    document
                        .getElementById("hero")
                        ?.scrollIntoView({ behavior: "smooth" });
                }}
                className="mt-6 inline-block rounded-lg bg-[var(--text-h)] px-7 py-3 font-medium text-[var(--bg)] transition hover:opacity-80"
            >
                Kembali ke Atas
            </a>
        </div>
    </section>
  );
}